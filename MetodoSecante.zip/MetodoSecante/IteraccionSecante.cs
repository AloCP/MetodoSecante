﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetodoSecante
{
    internal class IteracionSecante
    {
        public int Iteracion;
        public float X0;
        public float XI;
        public float Fx0;
        public float FxI;
        public float X2;
        public float Error;
    }
}
